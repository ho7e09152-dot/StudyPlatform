# Workspace Entry & Onboarding screenshots

Final visual QA for the Workspace Hub, repository connection flow, restore flow, first Workspace, and profile onboarding.

- `desktop/`: 1440 × 1050
- `mobile/`: 390 × 844
- `qa-results.json`: overflow and browser error checks

Each viewport contains:

1. Workspace Hub
2. Workspace Switcher / Mobile Workspace navigation
3. Repository Search
4. Repository Selected
5. Permission Loading
6. Permission Success
7. Existing Study Data
8. New Repository
9. Conflict
10. Permission Denied
11. Restore
12. First Workspace
13. Profile Onboarding
